import "./App.css";
// import ConditionalRendering from "./components/ConditionalRendering";
// import FormComponent from "./components/FormComponent";
import FormikComponent from "./components/FormikComponent";
// import ShoppingComponent from "./components/ShoppingComponent";
// import ShoppingWithProps from "./components/ShoppingWithProps";
// import EventBinding from './components/EventBinding';
// import TwoWayBinding from './components/TwoWayBinding';

function App() {
  return (
    <div className="App">
      {/* <header className="App-header">
        <EventBinding/>
        <TwoWayBinding/>
      </header> */}
      <div>
        {/* <ShoppingComponent /> */}
        {/* <ShoppingWithProps /> */}
        {/* <ConditionalRendering/> */}
        {/* <FormComponent /> */}
        <FormikComponent />
      </div>
    </div>
  );
}

export default App;
